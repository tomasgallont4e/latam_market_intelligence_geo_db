// Adaptador independiente; recibe map_payload.json ya leído por el servidor.
// No ejecuta escrituras ni supone el API interno de lib/mapData.js.
export function createPersonaMapAdapter(data) {
  const cities = new Set(['05001', '76001']);
  const zoneMap = new Map(data.zones.map(z => [z.zone_id, z]));
  function getCityPersonaDistribution(municipalityCode, persona = null) {
    if (!cities.has(municipalityCode)) throw new Error('Código de municipio fuera del paquete');
    return {
      municipality_code: municipalityCode,
      geographic_scope: 'metropolitan_area',
      reference_year: 2025,
      values: data.personas.filter(r => r.municipality_code === municipalityCode && (!persona || r.persona === persona)).map(r => ({...r, employed: Number(r.employed)})),
      summary: data.metroSummary.find(r => r.municipality_code === municipalityCode),
      profiles: data.profiles.filter(r => r.municipality_code === municipalityCode && (!persona || r.persona === persona)),
      segments: data.segments.filter(r => r.municipality_code === municipalityCode && (!persona || r.persona === persona)),
    };
  }
  function getZoneProfile(zoneId, persona = null) {
    const zone = zoneMap.get(zoneId);
    if (!zone) throw new Error('Zona fuera del paquete');
    return {
      zone,
      local_persona_count: null,
      local_persona_status: 'not_available',
      metro_context: getCityPersonaDistribution(zone.municipality_code, persona),
    };
  }
  return {getCityPersonaDistribution, getZoneProfile};
}
