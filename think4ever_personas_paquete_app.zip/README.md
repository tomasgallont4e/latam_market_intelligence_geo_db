# Paquete de distribución de personas para Think4Ever

## Alcance

Consolida lo disponible para **Medellín y Cali** en las llaves de la aplicación: `municipality_code` como texto de cinco dígitos y `zone_id`. No crea una distribución modelada por comunas. La distribución de las 13 personas se presenta en la capa de ciudades/dominios metropolitanos; los polígonos muestran indicadores locales que sí existen.

Se conserva Bogotá en producción: este paquete solo aporta 43 zonas MED/CAL, no reemplaza toda la base. Los periodos se mantienen por fuente, sin exigir que todos sean2025.

| Información | Medellín | Cali |
|---|---|---|
| Polígonos | 16 comunas y5corregimientos | 22 comunas urbanas |
| Distribución de13personas | GEIH2025, Medellín A.M. | GEIH2025, Cali–Yumbo |
| Perfiles de audiencia | Edad, ingreso, educación, posición laboral y muestras por persona/dominio | Igual |
| Segmentos laborales | Persona×dominio×tipo de comprador | Igual |
| Residentes por zona | ECV local2025: población, ocupados y otros indicadores | Población proyectada2021, ASIS |
| Empresas por zona | 2022: total y categorías CIIU | 2025: total y tamaño por ingresos |
| Conteo de cada persona por comuna | No disponible | No disponible |

## Archivos para la app

- `geo_zone.csv`:43zonas con las diez columnas del contrato adjunto. GeoJSON y WKT enWGS84; `geometry` se entrega como WKT para convertir en destino si usaPostGIS. Puntos interiores para etiquetas, no domicilios.
- `fact_persona_metro.csv`:26filas, columnas exactas de contenido `persona,municipality_code,metro_area,employed`. La capital ancla el dominio; no convierte el conteo en municipal exclusivo.
- `fact_persona_segment.csv`:formato de contenido existente `persona,municipality_code,city,buyer_type,employed,interviews`. No requiere conservar los IDs autoincrementales de muestras anteriores.
- `fact_persona_profile_metro_2025.csv`, `fact_persona_segment_metro_2025.csv`, `fact_geih2025_metro_summary.csv`:perfiles extendidos, segmentos y totales con año/ámbito. No reemplazar el perfil nacional con uno metropolitano.
- `fact_zone_context.csv`, `fact_zone_indicator.csv`:hechos locales amplios y por indicador. Usar esta tabla genérica para Medellín/Cali; no insertar estos resultados bajo atribución `fact_em2021_localidad`.
- `fact_companies_zone.csv`:43zonas empresariales, columnas existentes; valores desconocidos vacíos. El antiguo indicador `sin_geografia` se omite: usar la geometría actual y no el estado anterior a recuperar polígonos.
- `meta_companies_zone.csv`, `meta_geo_zone.csv`, `meta_sources.csv`:procedencia, periodos, criterio de tamaño y licencia. La licencia de Medellín no queda autorizada por este paquete.
- `control_empresas_sin_ubicacion.csv`:gruposMED-00/CAL-00fuera de los polígonos. No repartirlos entre comunas.
- `map_payload.json`:datos consolidados para consumo por un adaptador; geometrías completas se importan desde elCSV.
- `mapAdapter.mjs`:adaptadorJavaScript independiente con `getCityPersonaDistribution()` y `getZoneProfile()`. No presupone ni modifica interfaces internas de `lib/mapData.js`. La selección de una persona filtra perfiles metropolitanos; **nunca produce un conteo local**.
- `personas_app_medellin_cali.sqlite`:base independiente con geometría y hechos; vista `map_zone_context` de43filas. No es una copia de toda la base nacional de producción.
- `construir.py`, `validation.json`:reconstrucción desde las entregas anteriores y controles ejecutados.

## Comportamiento esperado

Al seleccionar Medellín o Cali, mostrar las13personas del dominioGEIH2025, su magnitud y características. En el filtro de persona, mantener el mismo ámbito metropolitano.

Al seleccionar una comuna, mostrar su población y/o actividad empresarial con año y fuente; el contextoGEIH aparece separado como “Medellín A.M.” o “Cali–Yumbo”. El resultado del adaptador devuelve `local_persona_count:null`, no cero. No colorear comunas con el total metropolitano ni sumar ese total una vez por polígono.

Ejemplo conceptual:

```js
import {createPersonaMapAdapter} from './mapAdapter.mjs';
const adapter = createPersonaMapAdapter(payload);
const city = adapter.getCityPersonaDistribution('05001', 'Software developers and analysts');
const zone = adapter.getZoneProfile('MED-14', 'Software developers and analysts');
// zone.local_persona_count === null
// zone.zone contiene residentes y empresas locales con sus años.
// zone.metro_context contiene desarrolladores del dominio Medellín A.M.
```

## Integración concreta pendiente en el repositorio

1. Importar `geo_zone` por `zone_id`, respetando políticas existentes de licencia. Mantener Bogotá. Si ya están las43zonas, actualizar sin duplicar.
2. Hacer upsert de `fact_persona_metro` por `(persona,municipality_code)`; registrarGEIH2025en metadatos. La importación reemplaza los resultados de esos dominios, no añade copias.
3. Importar empresas por `zone_id`, con fuente/año separado. Importar segmentos por `(persona,municipality_code,buyer_type)` y hechos locales por sus claves. Importar vacíos comoNULL.
4. Añadir en `lib/loader.js` carga de tablas nuevas y en `lib/mapData.js` lectura de hechos locales genéricos y panel de contexto metropolitano. Puede reutilizarse el adaptador incluido como lógica de selección.
5. Mantener elCSVde personas por localidad deBogotá y sus mecanismos actuales. No crear unCSVde personas por comuna MED/CALrellenado con ceros.
6. Registrar63zonas totales si conserva20BOG+21MED+22CAL. Controles del paquete:43zonas,26persona×dominio,43filas de empresas,0conteos locales de marketingpersonas.
7. Mostrar fuente/año/universo. Las categorías de empresas no se convierten en ocupaciones. TamañoCali por ingresos no es equivalente a tamañoBogotá por activos.

No se tuvo acceso al repositorio de la aplicación ni se desplegó esta integración. Se verificó el contrato frente al esquema adjunto y se probaron laSQLite y el adaptador, no la importación real en producción.

## Calidad y límites que afectan los datos

GEIH:promedio de12meses2025conFEX_C18y códigos ocupacionales de las13personas ya procesados. Muestraspequeñas identificadas en perfiles; no hay intervalos/CVEcalculados con diseño complejo. Trabajar en vivienda no demuestra teletrabajo.

Cali:población2021por código de comuna sobre cartografía2026; sin armonización histórica de límites. Las22filas suman2.174.660frente a subtotalurbano2.217.961en el documento fuente; se conservaron filas sin forzar el total.

Medellín:ocupados residentes estimados conECV2025, no puestos de trabajo localizados. La fuente no ofrece el detalle ocupacional necesario para contar las13personas por zona.

Conteo total del dominio y suma de categorías redondeadas pueden diferir. Consultar el total agregado una vez y documentar su método. La entrega recalculada totaliza241.904personasMedellínA.M.y101.436Cali–Yumbo, sin redistribución espacial.

## Reproducir

El adaptador de datos requiere las entregas anteriores dentro de `outputs`:carpetas`poblacion_think4ever`, `medellin_cali` y `medellin_cali_2025`. Los insumos grandes de esas entregas no se duplican en esteZIP.

```bash
python construir.py /ruta/outputs /ruta/resultado
```

El script reemplaza solo suSQLitede salida con el nombre indicado. Elegir una carpeta nueva para reproducir. No conecta a producción ni descarga fuentes.

## Procedencia

- GEIH2025:DANE, catálogo853, https://microdatos.dane.gov.co/index.php/catalog/853/get-microdata.
- ECVMedellín2025: https://www.medellin.gov.co/es/wp-content/uploads/2022/08/ECV_2025.xlsx.
- EmpresasMedellín2022: https://www.datos.gov.co/resource/pb3w-3vmc.json.
- EmpresasCali2025: https://www.ccc.org.co/informacion-y-estudios-economicos/tableros-economicos/.
- PoblaciónCali2021:ASIS2021,Tabla2,páginaPDF28; https://www.minsalud.gov.co/sites/rid/Lists/BibliotecaDigital/RIDE/VS/ED/PSP/asis-cali-distrito-2021.pdf.

Esta entrega reutiliza datos previamente extraídos y calculados; no declara una nueva actualización de todas las fuentes. Cartografía y restricciones en `meta_geo_zone.csv`.
