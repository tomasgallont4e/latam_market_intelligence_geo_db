"""python construir.py DIRECTORIO_ENTREGAS SALIDA
Usa las entregas existentes; no descarga, estima ni reparte personas por comuna.
"""
import csv,json,shutil,sqlite3,sys
from pathlib import Path
csv.field_size_limit(100000000)
def read(p):return list(csv.DictReader(open(p,encoding='utf-8-sig',newline='')))
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main(root,out):
 root,out=Path(root),Path(out);out.mkdir(parents=True,exist_ok=True)
 src=root/'poblacion_think4ever';codes={'05001','76001'}
 geo=read(root/'medellin_cali_2025/geo_zone.csv');assert len(geo)==43
 write(out/'geo_zone.csv',geo)
 locals=[r for r in read(src/'fact_zone_context.csv') if r['municipality_code'] in codes]
 companies=read(root/'medellin_cali/fact_companies_zone_medellin_cali.csv')
 excluded=[r for r in companies if r['zone_id'].endswith('-00')];companies=[r for r in companies if not r['zone_id'].endswith('-00')]
 for r in companies:r.pop('sin_geografia',None)
 tables={'fact_zone_context':locals,'fact_companies_zone':companies,'fact_persona_metro':[r for r in read(src/'fact_persona_metro_3_ciudades.csv') if r['municipality_code'] in codes]}
 for n in ['fact_persona_profile_metro_2025','fact_persona_segment_metro_2025','fact_geih2025_metro_summary']:
  tables[n]=[r for r in read(src/(n+'.csv')) if r['municipality_code'] in codes]
 tables['fact_persona_segment']=[{k:r[k] for k in ['persona','municipality_code','city','buyer_type','employed','interviews']} for r in tables['fact_persona_segment_metro_2025']]
 tables['fact_zone_indicator']=[r for r in read(src/'fact_zone_indicator.csv') if r['zone_id'].startswith(('MED-','CAL-'))]
 tables['meta_companies_zone']=[r for r in read(root/'medellin_cali/meta_companies_zone_medellin_cali.csv') if not r['zone_id'].endswith('-00')]
 for n,rows in tables.items():write(out/(n+'.csv'),rows)
 write(out/'control_empresas_sin_ubicacion.csv',excluded)
 shutil.copyfile(root/'medellin_cali_2025/meta_geo_zone.csv',out/'meta_geo_zone.csv')
 assert len(locals)==43 and all(not r['personas13'] and not r['core_it'] for r in locals)
 assert len(tables['fact_persona_metro'])==26 and len(companies)==43
 c=sqlite3.connect(':memory:');c.row_factory=sqlite3.Row
 c.execute("ATTACH DATABASE ? AS original",(str(src/'think4ever_terreno_poblado.sqlite'),))
 payload={'scope':'Medellin and Cali, no commune-level occupational allocation','zones':[], 'personas':tables['fact_persona_metro'],'profiles':tables['fact_persona_profile_metro_2025'],'segments':tables['fact_persona_segment_metro_2025'],'metroSummary':tables['fact_geih2025_metro_summary']}
 def typed(r):
  rr={}
  text={'zone_id','municipality_code','zone_type','zone_name','reference_year','source_id','personas_status','boundary_comparability'}
  for k,v in r.items():rr[k]=None if v=='' else v if k in text else float(v)
  return rr
 cmap={r['zone_id']:r for r in companies};lmap={r['zone_id']:r for r in locals}
 for g in geo:
  z={k:g[k] for k in ['zone_id','municipality_code','zone_type','zone_code','name','lat','lon']}
  z['residents']=typed(lmap[g['zone_id']]);z['companies']=typed(cmap[g['zone_id']]);z['companiesYear']=2022 if g['zone_id'].startswith('MED') else 2025
  z['localPersonas']=None;z['localPersonasStatus']='not_available';payload['zones'].append(z)
 (out/'map_payload.json').write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':')))
 db=out/'personas_app_medellin_cali.sqlite';db.unlink(missing_ok=True);dest=sqlite3.connect(db)
 c.backup(dest)
 # La copia en memoria no contiene tablas principales: importar CSV con tipos controlados.
 for name,rows in {'geo_zone':geo,**tables}.items():
  cols=list(rows[0]);text={'zone_id','municipality_code','zone_type','zone_code','name','zone_name','lat_unused','geojson','wkt','geometry','persona','metro_area','city','buyer_type','reference_year','survey_year','source_id','geographic_scope','method','personas_status','boundary_comparability','sample_flag','indicator','unit','size_basis','scope','status','source_url'}
  dest.execute('CREATE TABLE "'+name+'" ('+','.join('"'+k+'" '+('TEXT' if k in text else 'REAL') for k in cols)+')')
  dest.executemany('INSERT INTO "'+name+'" VALUES ('+','.join('?' for k in cols)+')',[tuple(None if r[k]=='' else r[k] if k in text else float(r[k]) for k in cols) for r in rows])
 dest.execute('CREATE UNIQUE INDEX zone_key ON geo_zone(zone_id)')
 dest.execute('CREATE UNIQUE INDEX persona_key ON fact_persona_metro(persona,municipality_code)')
 dest.execute('CREATE VIEW map_zone_context AS SELECT g.*, f.population, f.employed, f.personas13, f.core_it, f.reference_year AS residents_year, f.source_id AS residents_source, f.hh_computer_or_tablet_pct, f.dwelling_internet_pct, f.adults_university_pct, f.population_18_34_pct, c.companies_total, c.micro, c.medium_large, c.software_it, m.reference_year AS companies_year FROM geo_zone g LEFT JOIN fact_zone_context f USING(zone_id) LEFT JOIN fact_companies_zone c USING(zone_id) LEFT JOIN meta_companies_zone m USING(zone_id)')
 assert dest.execute('SELECT COUNT(*) FROM map_zone_context').fetchone()[0]==43
 assert dest.execute('SELECT COUNT(*) FROM map_zone_context WHERE personas13 IS NOT NULL').fetchone()[0]==0
 dest.commit();assert dest.execute('PRAGMA integrity_check').fetchone()[0]=='ok';dest.close();c.close()
 (out/'validation.json').write_text(json.dumps({'zones':43,'personas_metro':26,'companies_zones':43,'local_personas_rows':0,'years':{'geih':2025,'residents_medellin':2025,'residents_cali':2021,'companies_medellin':2022,'companies_cali':2025},'metro_allocated_to_zones':False,'sql_integrity':'ok','app_modified':False},indent=2))
if __name__=='__main__':main(*sys.argv[1:])
